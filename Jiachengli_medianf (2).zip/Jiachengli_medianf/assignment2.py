#import soundfile as sf
from scipy.io import wavfile
import wave
import numpy as np
import unittest
fs, audio = wavfile.read("degraded.wav")
fsc, audioc = wavfile.read("clean.wav")
print(fs)
print(audio)
print(fsc)
print(audioc)
audio_error = 2 * audio - audioc
print(2 * audio)
detection = []
for i in range (0, (len(audio_error) - 1)):
    if (audio_error[i] == 0):
        detect = 0
    else:
        detect = 1
    detection.append(detect)
print(detection)

def mid_filter(x, d):
    """take several numbers, return several middle numbers
    
    Args:
        x: an array of several numbers
        d: a natural number

    Returns: 
        output: returns the array of several numbers

    
    
    """
    filter_x = np.zeros((1, len(x)))
    if d % 2 == 0:
        return 'incorrect d'

    else:
        output = []
        for i in range (0, len(x) - 1):
            x_block = x[i : (d + i)]
            x_block = sorted(x_block)
            if (d // 2 == 0):
                filter_x[0, i] = (x[(d // 2) + i] + x[(d  // 2) + 1 + i]) / 2
            else: 
                middle = x[(d // 2) + i]
                output.append(middle)
    return output

block_size = 3
for i in range (0, len(detection)):
    if (detection[i] == 1):
        pre_x = audio[(i-2) : (i+2)]
        audio[i] = np.mean(mid_filter(pre_x, block_size))
print(audio)
actual_error = 2 * audio - audioc
_realdetection = []
for i in range (0, (len(actual_error) - 1)):
    if (actual_error[i] == 0):
        detect = 0
    else:
        detect = 1
    _realdetection.append(detect)
print(_realdetection)